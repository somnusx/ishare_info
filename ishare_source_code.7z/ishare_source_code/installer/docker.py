# uncompyle6 version 3.8.0
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 16 2020, 22:23:17) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-44)]
# Warning: this version of Python has problems handling the Python 3 byte type in constants properly.

# Embedded file name: installer/docker.py
import os, shutil, subprocess

def process(image, downloader):
    target = downloader.getTarget()
    print('Scand all files downloaded and load to docker')
    for path, subdirs, files in os.walk(target):
        for name in files:
            filePath = os.path.join(path, name)
            subprocess.call('docker load < ' + filePath, shell=True)
# okay decompiling docker.pyc
