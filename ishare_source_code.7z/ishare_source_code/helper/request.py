# uncompyle6 version 3.8.0
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.5 (default, Nov 16 2020, 22:23:17) 
# [GCC 4.8.5 20150623 (Red Hat 4.8.5-44)]
# Warning: this version of Python has problems handling the Python 3 byte type in constants properly.

# Embedded file name: helper/request.py
import requests, json

def get(url, param={}):
    try:
        r = requests.get(url, params=param)
        r.raise_for_status()
        return json.loads(r.text)
    except requests.exceptions.HTTPError as err:
        print(err.response.text)
        return False


def post(url, datas={}):
    try:
        r = requests.post(url, data=datas)
        r.raise_for_status()
        return json.loads(r.text)
    except requests.exceptions.HTTPError as err:
        print(err.response.text)
        return False
# okay decompiling request.pyc
